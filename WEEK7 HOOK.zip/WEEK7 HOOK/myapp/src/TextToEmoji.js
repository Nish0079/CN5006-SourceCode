import React, { useState } from "react";
import Happy from "./Happy.png";
import Sad from "./Sad.png";
import Like from "./Like.png";

function TextToEmoji() {
    const [emoji, setEmoji] = useState(null);

    const handleChange = (event) => {
        const value = event.target.value.toLowerCase();
        if (value === "happy") setEmoji(Happy);
        else if (value === "sad") setEmoji(Sad);
        else if (value === "like") setEmoji(Like);
        else setEmoji(null);
    };

    return (
        <div>
            <input type="text" placeholder="Enter emotion" onChange={handleChange} />
            <div>
                {emoji ? <img src={emoji} alt="Emotion" /> : <p>Type 'Happy', 'Sad', or 'Like'</p>}
            </div>
        </div>
    );
}

export default TextToEmoji;
