import './App.css';

function GreetingElement() {
  const greeting = 'Hello, Functional Component!';
  return (
    <div className="App">
      <h1>{greeting}</h1>
    </div>
  );
}

export default GreetingElement;
