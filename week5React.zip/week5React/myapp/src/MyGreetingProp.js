import './App.css';

function GreetingElementwithProp(props) {
  return (
    <div className="App">
      <h1>{props.msg}</h1>
    </div>
  );
}

export default GreetingElementwithProp;
