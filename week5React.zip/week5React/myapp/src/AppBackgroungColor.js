import './App.css';

function AppColor(props) {
  function changeColor() {
    document.body.style.backgroundColor = props.color;
  }

  return (
    <div className="App">
      <h1>{props.heading}</h1>
      <button onClick={changeColor}>Change Background to {props.color}</button>
    </div>
  );
}

export default AppColor;
