const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

// Exercise 1: Basic Express Hello World
app.get("/", (req, res) => {
  res.send("Hello, it is my first Express application!");
});

// Exercise 2: Additional Routes
app.get("/about", (req, res) => {
  res.send("This is a basic Express application");
});

app.get("/users/:userId/books/:bookId", (req, res) => {
  res.send(req.params);
});

// Exercise 3: Read JSON File
app.get("/GetStudents", (req, res) => {
  fs.readFile(__dirname + "/Student.json", "utf8", (err, data) => {
    if (err) {
      res.status(500).send("Error reading JSON file");
      return;
    }
    res.json({
      status: true,
      Status_Code: 200,
      "requested at": new Date(),
      requrl: req.url,
      "request Method": req.method,
      studentdata: JSON.parse(data),
    });
  });
});

// Exercise 3: Search JSON by ID
app.get("/GetStudentid/:id", (req, res) => {
  fs.readFile(__dirname + "/Student.json", "utf8", (err, data) => {
    if (err) {
      res.status(500).send("Error reading JSON file");
      return;
    }
    const students = JSON.parse(data);
    const student = students[`Student${req.params.id}`];
    if (student) {
      res.json(student);
    } else {
      res.status(404).json({ error: "Student not found" });
    }
  });
});

// Exercise 4: Serve HTML Form
app.get("/studentinfo", (req, res) => {
  res.sendFile("StudentInfo.html", { root: __dirname });
});

// Exercise 4: Handle POST Form Data
app.post("/submit-data", (req, res) => {
  const name = `${req.body.firstName} ${req.body.lastName}`;
  const age = `${req.body.myAge} Gender: ${req.body.gender}`;
  const qualification = req.body.Qual ? `Qualification: ${req.body.Qual}` : "No qualifications provided";

  res.send({
    status: true,
    message: "Form Details",
    data: { name, age, qualification },
  });
});

// Start the Server
app.listen(5000, () => {
  console.log("Server is running on port 5000");
});
