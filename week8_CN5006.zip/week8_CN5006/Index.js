// Import Mongoose
const mongoose = require('mongoose');

// MongoDB connection URI
const MONGO_URI = 'mongodb://localhost:27017/Week8';

// Connect to MongoDB
mongoose.connect(MONGO_URI, {
  useUnifiedTopology: true,
  useNewUrlParser: true
});

const db = mongoose.connection;

// Handle connection errors
db.on('error', (err) => {
  console.log("Error occurred during connection: " + err);
});

// Handle successful connection
db.once('connected', () => {
  console.log(`Connected to ${MONGO_URI}`);
});

// Define a Schema
const PersonSchema = new mongoose.Schema({
  name: { type: String, required: true },
  age: Number,
  Gender: String,
  Salary: Number
});

// Create a Model
const Person = mongoose.model('Person', PersonSchema, 'personCollection');

// Task 1: Add a Single Document
const addSingleDocument = async () => {
  const doc = new Person({ name: 'Jacky', age: 36, Gender: "Male", Salary: 3456 });
  try {
    const result = await doc.save();
    console.log("New document added:", result);
  } catch (err) {
    console.error(err);
  }
};

// Task 2: Add Multiple Documents
const addMultipleDocuments = async () => {
  const persons = [
    { name: 'Simon', age: 42, Gender: "Male", Salary: 3456 },
    { name: 'Neesha', age: 23, Gender: "Female", Salary: 1000 },
    { name: 'Mary', age: 27, Gender: "Female", Salary: 5402 },
    { name: 'Mike', age: 40, Gender: "Male", Salary: 4519 }
  ];
  try {
    const result = await Person.insertMany(persons);
    console.log("Multiple documents added:", result);
  } catch (err) {
    console.error(err);
  }
};

// Task 3: Fetch Data
const fetchData = async () => {
  try {
    const documents = await Person.find().limit(5);
    console.log("Documents fetched:", documents);
  } catch (err) {
    console.error(err);
  }
};

// Task 4: Fetch Data with Filter
const fetchFilteredData = async () => {
  try {
    const documents = await Person.find({ Gender: "Female", age: { $gt: 25 } });
    console.log("Filtered documents:", documents);
  } catch (err) {
    console.error(err);
  }
};

// Task 5: Count Documents
const countDocuments = async () => {
  try {
    const count = await Person.countDocuments();
    console.log("Total document count:", count);
  } catch (err) {
    console.error(err);
  }
};

// Task 6: Delete Documents with Criteria
const deleteDocuments = async () => {
  try {
    const result = await Person.deleteMany({ age: { $gte: 25 } });
    console.log("Documents deleted:", result);
  } catch (err) {
    console.error(err);
  }
};

// Task 7: Update Documents
const updateDocuments = async () => {
  try {
    const result = await Person.updateMany(
      { Gender: "Female" },
      { Salary: 5555 }
    );
    console.log("Documents updated:", result);
  } catch (err) {
    console.error(err);
  }
};

// Execute Tasks
const runTasks = async () => {
  await addSingleDocument();
  await addMultipleDocuments();
  await fetchData();
  await fetchFilteredData();
  await countDocuments();
  await deleteDocuments();
  await updateDocuments();
};

runTasks().then(() => {
  console.log("All tasks completed.");
  mongoose.disconnect();
});
